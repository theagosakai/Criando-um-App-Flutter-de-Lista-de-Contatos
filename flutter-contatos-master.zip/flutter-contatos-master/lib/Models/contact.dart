class Contact {
    String name;
    String phone;
    String email;
  
    Contact(this.name, this.phone, this.email);
}