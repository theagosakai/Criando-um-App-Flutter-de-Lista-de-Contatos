# flutter-contatos

Aplicativo de lista de contatos para aprendizado de [Flutter](<https://flutter.io/>)

## Funcionalidades

* Adicionar contatos
* Ver lista com os contatos adicionados
* Ver detalhes de um contato
* Apagar um contato
* Ver mapa com localização dos contatos
* Adicionar contato como favorito
